//
//  MJPerson.m
//  Interview01-Runtime
//
//  Created by MJ Lee on 2018/5/17.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"

@interface MJPerson()
{
    //char占一个字节，8位
    //结构体支持位域，使用:1代表只占一位,这时候就不看左边的char了
    //这时候整个结构体就占3位，系统不可能分配3位给它，所以至少占用一个字节
    struct {
        char tall : 1;
        char rich : 1;
        char handsome : 1;
    } _tallRichHandsome; // 0b0000 0000
    //最后三位放上面的值，而且前面的成员放在最右边(tall最后一位，rich倒数第二位，handsome倒数第三位)
}
@end

@implementation MJPerson

- (void)setTall:(BOOL)tall
{
    _tallRichHandsome.tall = tall;
}

- (BOOL)isTall
{
    //将0b1 -> 0b0000 0000
    //BOOL值是8位二进制，但是我们存下来的是一位(0b1),如何将一位转成8位二进制呢？取反再取反
    //如果不做两次取反操作，系统会自动把所有的0都b赋值为1，就是0b1 -> 0b1111 1111，就不对了
    return !!_tallRichHandsome.tall;
}

- (void)setRich:(BOOL)rich
{
    _tallRichHandsome.rich = rich;
}

- (BOOL)isRich
{
    return !!_tallRichHandsome.rich;
}

- (void)setHandsome:(BOOL)handsome
{
    _tallRichHandsome.handsome = handsome;
}

- (BOOL)isHandsome
{
    return !!_tallRichHandsome.handsome;
}

@end
