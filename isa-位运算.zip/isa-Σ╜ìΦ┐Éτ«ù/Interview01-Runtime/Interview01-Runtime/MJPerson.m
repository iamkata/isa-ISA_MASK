//
//  MJPerson.m
//  Interview01-Runtime
//
//  Created by MJ Lee on 2018/5/17.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "MJPerson.h"

//什么是位运算？与或非运算 (& | ~)  感叹号!是给BOOL值取反的

//按位“与”，都是1结果才是1，其他结果都是0

//开发中使用掩码的按位与运算来取出特定位的值，想取出哪一位的值，就把哪一位置为1，其他为0
// 0000 0111
//&0000 0100
//------
// 0000 0100

//掩码按位或运算，可以将某一位置为1，而不改变其他位
//掩码取反的按位与运算，将某一位置为0,而不改变其他位

// 掩码，一般用来做按位与(&)运算的
//#define MJTallMask 0b00000001
//#define MJRichMask 0b00000010
//#define MJHandsomeMask 0b00000100

#define MJTallMask (1<<0) //1往左位移0位
#define MJRichMask (1<<1) //1往左位移1位
#define MJHandsomeMask (1<<2) //1往左位移2位

@interface MJPerson()
{
    char _tallRichHansome; //只占一个字节 0b 0000 0000
}
@end

@implementation MJPerson

- (instancetype)init
{
    if (self = [super init]) {
        _tallRichHansome = 0b00000100;
    }
    return self;
}

- (void)setTall:(BOOL)tall
{
    if (tall) {
        //掩码的按位或运算，将某一位置为1
        _tallRichHansome |= MJTallMask;
    } else {
        //掩码取反的按位与运算，将某一位置为0
        _tallRichHansome &= ~MJTallMask;
    }
}

- (BOOL)isTall
{
    //与运算之后，结果要么是0要么有值，但是我们需要的是BOOL值，怎么转换呢？
    //取反，再取反
    return !!(_tallRichHansome & MJTallMask);
}

- (void)setRich:(BOOL)rich
{
    if (rich) {
        _tallRichHansome |= MJRichMask;
    } else {
        _tallRichHansome &= ~MJRichMask;
    }
}

- (BOOL)isRich
{
    return !!(_tallRichHansome & MJRichMask);
}

- (void)setHandsome:(BOOL)handsome
{
    if (handsome) {
        _tallRichHansome |= MJHandsomeMask;
    } else {
        _tallRichHansome &= ~MJHandsomeMask;
    }
}

- (BOOL)isHandsome
{
    return !!(_tallRichHansome & MJHandsomeMask);
}

@end
