//
//  ViewController.m
//  Interview04-Class地址
//
//  Created by MJ Lee on 2018/5/17.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import "ViewController.h"
#import <objc/runtime.h>
#import "MJPerson.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"%p", [ViewController class]);
    NSLog(@"%p", object_getClass([ViewController class]));
    NSLog(@"%p", [MJPerson class]);
    NSLog(@"%p", object_getClass([MJPerson class]));
    
//    2019-12-04 15:04:09.659586+0800 Interview04-Class地址[9913:832017] 0x107f6ed88
//    2019-12-04 15:04:09.659692+0800 Interview04-Class地址[9913:832017] 0x107f6edb0
//    2019-12-04 15:04:09.659772+0800 Interview04-Class地址[9913:832017] 0x107f6ee50
//    2019-12-04 15:04:09.659828+0800 Interview04-Class地址[9913:832017] 0x107f6ee28
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
